package com.example.retrofitdemo1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.retrofitdemo1.api.ApiClient
import com.example.retrofitdemo1.model.Post
import retrofit2.Call
import retrofit2.Response
import javax.security.auth.callback.Callback

class MainActivity : AppCompatActivity() {
    var posts : ArrayList<Post>? = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getPosts()
    }

    fun getPosts(){
        val call = ApiClient.apiService.getPosts()
        call.enqueue(object : Callback, retrofit2.Callback<ArrayList<Post>>{
            override fun onResponse(
                call: Call<ArrayList<Post>>,
                response: Response<ArrayList<Post>>
            ) {
                posts = response.body();
                Log.e("PostResponse", response.body().toString())
            }

            override fun onFailure(call: Call<ArrayList<Post>>, t: Throwable) {
                Log.e("Post Failed", t.message!!)
            }

        })
    }
}