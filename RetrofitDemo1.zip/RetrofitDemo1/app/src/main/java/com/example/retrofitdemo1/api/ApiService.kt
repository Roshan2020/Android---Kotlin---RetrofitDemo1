package com.example.retrofitdemo1.api

import com.example.retrofitdemo1.model.Post
//import android.telecom.Call
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET("posts")
    fun getPosts(): retrofit2.Call<ArrayList<Post>>
}